package com.example.beautifulksu.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.beautifulksu.ui.component.StatusCard

@Composable
fun HomeScreen(
    onNavigateToModules: () -> Unit = {},
    onNavigateToSuperUser: () -> Unit = {}
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(20.dp))

        Text(
            text = "ColorSU",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "隐藏性管理器",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(28.dp))

        StatusCard(
            title = "ColorSU 状态",
            subtitle = "版本 2.1.1 · LKM 模式",
            status = "正常-运行中",
            statusColor = Color(0xFF00E676),
            icon = Icons.Default.Security
        )

        Spacer(Modifier.height(14.dp))

        StatusCard(
            title = "超级用户",
            subtitle = "18 个应用已授权",
            status = "管理",
            statusColor = MaterialTheme.colorScheme.primary,
            icon = Icons.Default.AdminPanelSettings,
            onClick = onNavigateToSuperUser
        )

        Spacer(Modifier.height(14.dp))

        StatusCard(
            title = "模块",
            subtitle = "8 个已安装 · 2 个可更新",
            status = "查看",
            statusColor = MaterialTheme.colorScheme.secondary,
            icon = Icons.Default.Extension,
            onClick = onNavigateToModules
        )

        Spacer(Modifier.height(32.dp))

        Text(
            text = "快捷操作",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionChip("安装模块", Icons.Default.Add)
            QuickActionChip("超级用户", Icons.Default.Person)
            QuickActionChip("日志", Icons.Default.Article)
        }

        Spacer(Modifier.height(28.dp))

        // 提示卡片
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            )
        ) {
            Column(Modifier.padding(18.dp)) {
                Text(
                    "ColorSU管理器",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "当前版本包含美化ui，隐藏Tee路径。一键清理，请认准官方 ColorSU 或基于官方源码进行二次开发的FUdeck。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun QuickActionChip(text: String, icon: ImageVector) {
    AssistChip(
        onClick = {},
        label = { Text(text) },
        leadingIcon = {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        },
        shape = RoundedCornerShape(16.dp)
    )
}
