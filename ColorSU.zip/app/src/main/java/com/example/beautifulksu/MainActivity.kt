package com.example.beautifulksu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.beautifulksu.ui.screen.HomeScreen
import com.example.beautifulksu.ui.screen.ModuleScreen
import com.example.beautifulksu.ui.screen.SettingsScreen
import com.example.beautifulksu.ui.screen.SuperUserScreen
import com.example.beautifulksu.ui.theme.BeautifulKsuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BeautifulKsuTheme {
                BeautifulKsuApp()
            }
        }
    }
}

private data class TabItem(
    val title: String,
    val icon: ImageVector
)

@Composable
fun BeautifulKsuApp() {
    var selectedTab by remember { mutableIntStateOf(0) }

    val tabs = listOf(
        TabItem("首页", Icons.Default.Home),
        TabItem("模块", Icons.Default.Extension),
        TabItem("超级用户", Icons.Default.AdminPanelSettings),
        TabItem("设置", Icons.Default.Settings)
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                tonalElevation = 0.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> HomeScreen(
                    onNavigateToModules = { selectedTab = 1 },
                    onNavigateToSuperUser = { selectedTab = 2 }
                )
                1 -> ModuleScreen()
                2 -> SuperUserScreen()
                3 -> SettingsScreen()
            }
        }
    }
}
