package com.example.beautifulksu.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class FakeModule(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val enabled: Boolean,
    val hasUpdate: Boolean = false
)

@Composable
fun ModuleScreen() {
    val modules = remember {
        listOf(
            FakeModule("lsposed", "LSPosed", "1.9.2", "LSPosed Developers", true, true),
            FakeModule("pif", "Play Integrity Fix", "17.3", "chiteroman", true),
            FakeModule("shamiko", "Shamiko", "1.1.1", "LSPosed", true),
            FakeModule("zygisksu", "ZygiskNext", "1.2.5", "Dr-TSNG", false),
            FakeModule("tricky", "Tricky Store", "1.2.0", "5ec1cff", true, true),
            FakeModule("susfs", "Susfs4KSU", "1.5.2", "simonpunk", true),
        )
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "模块",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
        )

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(modules) { module ->
                ModuleItem(module)
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun ModuleItem(module: FakeModule) {
    var enabled by remember { mutableStateOf(module.enabled) }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Extension,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )

            Spacer(Modifier.width(14.dp))

            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        module.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (module.hasUpdate) {
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                        ) {
                            Text(
                                "更新",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }
                Text(
                    "${module.version} · ${module.author}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = enabled,
                onCheckedChange = { enabled = it }
            )
        }
    }
}
