package com.example.beautifulksu.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF7C4DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A148C),
    onPrimaryContainer = Color(0xFFE8DEF8),
    secondary = Color(0xFF00E5FF),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF006064),
    onSecondaryContainer = Color(0xFFB2EBF2),
    tertiary = Color(0xFFFF8A65),
    background = Color(0xFF0F0F13),
    onBackground = Color(0xFFE8E8ED),
    surface = Color(0xFF1A1A22),
    onSurface = Color(0xFFE8E8ED),
    surfaceVariant = Color(0xFF2A2A35),
    onSurfaceVariant = Color(0xFFB0B0C0),
    error = Color(0xFFFF5252),
    outline = Color(0xFF3D3D4A)
)

@Composable
fun BeautifulKsuTheme(
    darkTheme: Boolean = true, // 强制深色优先
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
