package com.example.beautifulksu.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    var checkUpdate by remember { mutableStateOf(true) }
    var hideKsu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Text(
            text = "设置",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Text("通用", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))

        ListItem(
            headlineContent = { Text("检查更新") },
            supportingContent = { Text("自动检查 ColorSU 更新") },
            trailingContent = {
                Switch(checked = checkUpdate, onCheckedChange = { checkUpdate = it })
            },
            leadingContent = { Icon(Icons.Default.SystemUpdate, null) }
        )

        ListItem(
            headlineContent = { Text("隐藏 ColorSU") },
            supportingContent = { Text("对部分应用隐藏 Root 痕迹——测试阶段") },
            trailingContent = {
                Switch(checked = hideKsu, onCheckedChange = { hideKsu = it })
            },
            leadingContent = { Icon(Icons.Default.VisibilityOff, null) }
        )

        Spacer(Modifier.height(24.dp))
        Text("关于", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))

        ListItem(
            headlineContent = { Text("版本") },
            supportingContent = { Text("ColorSU 2.0.1（正式版）") },
            leadingContent = { Icon(Icons.Default.Info, null) }
        )

        ListItem(
            headlineContent = { Text("基于") },
            supportingContent = { Text("Jetpack Compose + Material 3") },
            leadingContent = { Icon(Icons.Default.Code, null) }
        )

        Spacer(Modifier.height(40.dp))
    }
}
