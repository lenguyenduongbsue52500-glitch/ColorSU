package com.example.beautifulksu.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class FakeApp(
    val name: String,
    val packageName: String,
    val granted: Boolean
)

@Composable
fun SuperUserScreen() {
    val apps = remember {
        listOf(
            FakeApp("终端模拟器", "com.termux", true),
            FakeApp("MT 管理器", "bin.mt.plus", true),
            FakeApp("应用管理器", "com.github.promeg.xposed", false),
            FakeApp("绿色守护", "com.oasisfeng.greenify", true),
            FakeApp("冰箱", "com.catchingnow.icebox", false),
            FakeApp("Shizuku", "moe.shizuku.privileged.api", true),
        )
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "超级用户",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
        )

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(apps) { app ->
                SuperUserItem(app)
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun SuperUserItem(app: FakeApp) {
    var granted by remember { mutableStateOf(app.granted) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Android,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(36.dp)
            )

            Spacer(Modifier.width(14.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    app.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    app.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = granted,
                onCheckedChange = { granted = it }
            )
        }
    }
}
